# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
spark = SparkSession.builder \
    .master("local[1]") \
    .appName("SparkByExamples.com") \
    .getOrCreate()

data = [
    ("James",None,"M"),
    ("Anna","NY","F"),
    ("Julia",None,None)
  ]

columns = ["name","state","gender"]
df = spark.createDataFrame(data,columns)
df.show()



# COMMAND ----------

df.filter("state is NULL").show()


# COMMAND ----------

df.filter(df.state.isNull()).show()


# COMMAND ----------

df.filter(col("state").isNull()).show() 



# COMMAND ----------

df.na.drop(how='any').show()

# COMMAND ----------

df.na.drop(subset=["gender"]).show()

# COMMAND ----------

df.dropna().show(truncate=False)
  

# COMMAND ----------

