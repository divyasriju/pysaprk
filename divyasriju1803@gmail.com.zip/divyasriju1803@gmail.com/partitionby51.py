# Databricks notebook source
from pyspark.sql import SparkSession

# Create SparkSession
spark = SparkSession.builder \
          .appName('SparkByExamples.com') \
          .getOrCreate()

df=spark.read.option("header",True) \
        .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/simple_zipcodes.csv")

          
df.show()
print(df.rdd.getNumPartitions())



# COMMAND ----------

df.write.option("header",True) \
        .partitionBy("state") \
        .mode("overwrite") \
        .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/tmp/zipcodes-state")


display(df)

# COMMAND ----------

df.write.option("header",True) \
        .partitionBy("state","city") \
        .mode("overwrite") \
        .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/tmp/zipcodes-state-city")


df=df.repartition(2)

print(df.rdd.getNumPartitions())

display(df)

# COMMAND ----------

df.write.option("header",True) \
        .partitionBy("state") \
        .mode("overwrite") \
        .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/tmp/zipcodes-state-more")


df.show()
        

# COMMAND ----------

dfPartition=spark.read.option("header",True)\
                 .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/tmp/zipcodes-state")
dfPartition.printSchema()

# COMMAND ----------

dfSinglePart=spark.read.option("header",True)\
                  .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/tmp/zipcodes-state/state=AL")
dfSinglePart.printSchema()
dfSinglePart.show()



# COMMAND ----------

parqDF = spark.read.option("header",True) \
                  .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/tmp/zipcodes-state")

display(df)


# COMMAND ----------

parqDF.createOrReplaceTempView("ZIPCODE")
spark.sql("select * from ZIPCODE  where state='AL' and city = 'SPRINGVILLE'") \
    .show()

df.write.option("header",True) \
        .option("maxRecordsPerFile", 2) \
        .partitionBy("state") \
        .mode("overwrite") \
        .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/tmp/zipcodes-state-maxrecords")

display(df)

# COMMAND ----------

dfSinglePart=spark.read.option("header",True)\
                  .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/tmp/zipcodes-state-city/state=AL/city=SPRINGVILLE")
dfSinglePart.printSchema()
dfSinglePart.show()


# COMMAND ----------

