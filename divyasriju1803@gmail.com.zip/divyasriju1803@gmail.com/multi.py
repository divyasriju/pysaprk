# Databricks notebook source
df1=spark.read.csv(dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/emp.csv)
df2=spark.read.json(dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/divya.json)
df3=spark.read.txt(dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/data.txt)
display(df1)
display(df2)
display(df3)

# COMMAND ----------

