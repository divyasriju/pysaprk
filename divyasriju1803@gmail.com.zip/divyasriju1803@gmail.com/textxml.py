# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from decimal import Decimal
appName = "Python Example - PySpark Read XML"
master = "local"

# Create Spark session
spark = SparkSession.builder \
    .appName(appName) \
    .master(master) \
    .getOrCreate()

schema = StructType([
    StructField('_id', IntegerType(), False),
    StructField('rid', IntegerType(), False),
    StructField('name', StringType(), False)
])

df = spark.read.format("com.databricks.spark.xml") \
    .option("rowTag","record").load("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/text.xml", schema=schema)

df.show()


# COMMAND ----------

df.select("rid","name").write.format("csv").option("rootTag", "data").option("rowTag", "record").mode(
    "overwrite").save("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/test2.xml")

# COMMAND ----------

df.select("rid","name").write.format("xml").option("rootTag", "data").option("rowTag", "record").mode(
    "overwrite").save("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/5xml")

# COMMAND ----------



# COMMAND ----------

