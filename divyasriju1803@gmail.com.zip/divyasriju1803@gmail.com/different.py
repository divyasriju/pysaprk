# Databricks notebook source
empdf=spark.read.option("header","True").csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/employee.csv")
deptdf=spark.read.option("header","True").csv("empdf.join(deptdf,deptdf.depid==empdf.department,"right").show(truncate=False))
display(empdf)
display(deptdf)                      

empdf.join(deptdf,deptdf.depid==empdf.department,"inner").show(truncate=False)


# COMMAND ----------


df=empdf.join(deptdf,deptdf.depid==empdf.department,"left").show(truncate=False)
display(df)



# COMMAND ----------

empdf.join(deptdf,deptdf.depid==empdf.department,"right").show(truncate=False)

# COMMAND ----------

empdf.join(deptdf,deptdf.depid==empdf.department,"full").show(truncate=False)

# COMMAND ----------

empdf.join(deptdf,deptdf.depid==empdf.department,"leftanti").show(truncate=False)

# COMMAND ----------

empdf.join(deptdf,deptdf.depid==empdf.department,"leftsemi").show(truncate=False)

# COMMAND ----------

empdf.join(deptdf,deptdf.depid==empdf.department,"anti").show(truncate=False)

# COMMAND ----------

empdf.join(deptdf,deptdf.depid==empdf.department,"leftouter").show(truncate=False)


# COMMAND ----------

result=empdf.join(deptdf,deptdf.depid==empdf.department,"right")
display(result)

# COMMAND ----------

result.write.mode("overwrite").csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/output.csv",header="True")

# COMMAND ----------

sn=spark.read.csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/output.csv",header="True")
display(sn)

# COMMAND ----------

from pyspark.sql.functions import col
sn.withColumnRenamed("department","deptid")
display(sn)

# COMMAND ----------

from pyspark.sql.functions import col

df.withColumn("university",lit("1"))

display(df)

# COMMAND ----------



# COMMAND ----------

