# Databricks notebook source
import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('SparkByExamples.com') \
        .master("local[5]").getOrCreate()



# COMMAND ----------

df = spark.range(0,20)
print(df.rdd.getNumPartitions())



# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "500")

rdd = spark.sparkContext.parallelize((0,20))
print("From local[5]"+str(rdd.getNumPartitions()))

rdd1 = spark.sparkContext.parallelize((0,25), 6)
print("parallelize : "+str(rdd1.getNumPartitions()))



# COMMAND ----------

rddFromFile = spark.sparkContext.textFile("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/data.txt",20)
print("TextFile : "+str(rddFromFile.getNumPartitions()))

rdd1.saveAsTextFile("/tmp/data/partition2")



# COMMAND ----------

rdd2 = rdd1.repartition(4)
print("Repartition size : "+str(rdd2.getNumPartitions()))
rdd2.saveAsTextFile("/tmp/data1/re-partition2")



# COMMAND ----------

rdd3 = rdd1.coalesce(2)
print("coalesce size : " +str(rdd3.getNumPartitions()))
rdd3.saveAsTextFile("/tmp/data1/coalesce2")


# COMMAND ----------



# COMMAND ----------

