# Databricks notebook source
from pyspark.sql import SparkSession

# Create SparkSession
spark = SparkSession.builder \
          .appName('SparkByExamples.com') \
          .getOrCreate()

df=spark.read.option("header",True) \
        .csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/employee.csv")

newDF=df.repartition(2)
print(newDF.rdd.getNumPartitions())



# COMMAND ----------

newDF.write.option("header",True).mode("overwrite") \
        .csv("/tmp/zipcodes-state")



# COMMAND ----------

df2=df.repartition(3,"country")
df2.write.option("header",True).mode("overwrite") \
   .csv("/tmp/zipcodes-state-3states")



# COMMAND ----------

df3=df.repartition("country")
df3.write.option("header",True).mode("overwrite") \
   .csv("/tmp/zipcodes-state-allstates")

# COMMAND ----------

help(df.repartition)


# COMMAND ----------

