# Databricks notebook source
from pyspark.sql import SparkSession

spark: SparkSession = SparkSession.builder \
    .master("local[1]") \
    .appName("SparkByExamples.com") \
    .getOrCreate()

filePath="dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/survey_results_public.csv"
df = spark.read.options(header='true', inferSchema='true') \
          .csv(filePath)

df.printSchema()
df.show(truncate=False)

df.na.drop().show(truncate=False)

df.na.drop(how="any").show(truncate=False)

df.na.drop(subset=["Country","Employment"]) \
   .show(truncate=False)

df.dropna()
display(df)

# COMMAND ----------

filePath="dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/test.csv"
df = df.write.options(header='true', inferSchema='true',mode='overwrite') \
          .csv(filePath)
display(df)


# COMMAND ----------

