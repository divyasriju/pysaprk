# Databricks notebook source
from pyspark.sql.functions import monotonically_increasing_id
df = spark.read.option("nullValue","null").csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/employee.csv",header=True,inferSchema=True)
# Creating new column as partition_id using monotonically_increasing_id() function
df = df.withColumn("ID_KEY",monotonically_increasing_id())
display(df)

# COMMAND ----------

from pyspark.sql.functions import md5,col

# Creating new column as partition_id using md5() function
df  = df.withColumn("MD5_KEY",md5(col("empname").cast("string")))
display(df)

# COMMAND ----------

from pyspark.sql.functions import crc32,col

# Creating new column as partition_id using md5() function
df = df.withColumn("CRC32_KEY",crc32(col("empname").cast("string")))
display(df)

# COMMAND ----------

from pyspark.sql.functions import sha2

# Creating new column as partition_id using md5() function
df = df.withColumn("SHA2_KEY",sha2(col("empname").cast("string"),256))
display(df)

# COMMAND ----------

from pyspark.sql.functions import sha2,row_number,lit
from pyspark.sql.window import Window

# Creating new column as partition_id using md5() function
df =df.withColumn("ROW_NUMBER",row_number().over(Window.partitionBy(lit('')).orderBy(lit(''))))
display(df)