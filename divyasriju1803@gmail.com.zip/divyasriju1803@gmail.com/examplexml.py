# Databricks notebook source
from pyspark.sql import SparkSession



# Create Spark session
spark = SparkSession.builder.appName( "Python Example - PySpark Read XML").master("local").getOrCreate()


df = spark.read.format("xml").option("rootTag","root")\
    .option("rowTag","row").load("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/employee.xml")
df.printSchema()
df.show()

# COMMAND ----------

df=spark.read.text("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/employee.xml")

display(df)

# COMMAND ----------

df.select("*").write.format("xml").option("rootTag", "root").option("rowTag", "row").mode(
    "overwrite").save("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/5xml")

# COMMAND ----------

display(df)