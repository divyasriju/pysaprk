# Databricks notebook source
from pyspark.sql.functions import monotonically_increasing_id
df = spark.read.option("nullValue","null").csv("/FileStore/tables/emp.csv",header=True,inferSchema=True)
# Creating new column as partition_id using monotonically_increasing_id() function
df = df.withColumn("ID_KEY",monotonically_increasing_id())
display(df)

# COMMAND ----------

