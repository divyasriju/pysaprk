# Databricks notebook source
# MAGIC %md
# MAGIC #this is my first spark programs-to find datasets available in databricks

# COMMAND ----------

# MAGIC %sql
# MAGIC select current_date

# COMMAND ----------

dbutils.fs.ls('databricks-datasets')


# COMMAND ----------

