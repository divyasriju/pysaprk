# Databricks notebook source
from pyspark.sql import SparkSession 

spark = SparkSession \
    .builder \
    .appName("Python Spark Autoinsurance mini-example") \
    .getOrCreate()

# data = spark.table("insurance_claims")

fileStorePath = "dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/insurance_claims.csv"

data = spark.read.format("csv")\
          .options(inferSchema="true", header="true")\
          .load(fileStorePath)\
          .drop("_c39")
      
df = data.withColumn("policy_bind_date", data.policy_bind_date.cast("string"))\
         .withColumn("incident_date", data.incident_date.cast("string"))


# COMMAND ----------

display(df)

# COMMAND ----------

display(df.dtypes)

# COMMAND ----------

# Create a List of Column Names with data type = string
stringColList = [i[0] for i in df.dtypes if i[1] == 'string']
print (stringColList)


# COMMAND ----------

from pyspark.sql.functions import *

from pyspark.sql.functions import *

# Create a function that performs a countDistinct(colName)
distinctList = []
def countDistinctCats(colName):
  count = df.agg(countDistinctCats(colName)).collect()
  distinctList.append(count)

# COMMAND ----------

# Apply function on every column in stringColList
map(countDistinctCats, stringColList)
print(countDistinctCats)

# COMMAND ----------

display(df)

# COMMAND ----------

display(df.groupBy("fraud_reported").count())

# COMMAND ----------

display(df)

# COMMAND ----------

colsToDelete = ["policy_number", "policy_bind_date", "insured_zip", "incident_location", "incident_date"]
filteredStringColList = [i for i in stringColList if i not in colsToDelete]

# COMMAND ----------

from pyspark.ml.feature import StringIndexer

transformedCols = [categoricalCol + "Index" for categoricalCol in filteredStringColList]
stages = [StringIndexer(inputCol = categoricalCol, outputCol = categoricalCol + "Index") for categoricalCol in filteredStringColList]
stages

# COMMAND ----------

from pyspark.ml import Pipeline

indexer = Pipeline(stages=stages)
indexed = indexer.fit(df).transform(df)
display(indexed)