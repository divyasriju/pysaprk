# Databricks notebook source
configs = {"fs.azure.account.auth.type": "OAuth",
       "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
       "fs.azure.account.oauth2.client.id": "c08748bc-258f-48b7-a760-7dc9295b8c1a",
       "fs.azure.account.oauth2.client.secret": "44d3be6b-6788-4c90-b76c-d34e4a0159fa",
       "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/"cfe4f81b-e8c8-4e63-9fa0-1dab93055910"/oauth2/token",
       "fs.azure.createRemoteFileSystemDuringInitialization": "true"}

dbutils.fs.mount(
source = "abfss://<container-name>@<storage-account-name>.dfs.core.windows.net/folder1",
mount_point = "/mnt/flightdata",
extra_configs = configs)

# COMMAND ----------

dbutlis.fs.ls("/mnt/global")

# COMMAND ----------

