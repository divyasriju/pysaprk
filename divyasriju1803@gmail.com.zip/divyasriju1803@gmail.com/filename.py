# Databricks notebook source
df_airlines = spark.read.csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/2016_Stack_Overflow_Survey_Responses.csv",header=True)
from pyspark.sql.functions import input_file_name
df_airlines = df_airlines.withColumn("FILE_NAME",input_file_name())


display(df_airlines.groupBy("FILE_NAME").count())