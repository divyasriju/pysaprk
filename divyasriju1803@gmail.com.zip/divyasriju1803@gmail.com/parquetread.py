# Databricks notebook source
from pyspark.sql import SparkSession



# Create Spark session
spark = SparkSession.builder.appName( "Python Example - PySpark Read XML").master("local").getOrCreate()


df = spark.read.parquet('dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/userdata1.parquet')
#df.printSchema()



# Show 20 rows, column length 20 & displays data in vertical
df.show(n=20,truncate=20,vertical=True)
print(df.count())

# COMMAND ----------

help(spark.read.parquet)

# COMMAND ----------

df = spark.read.parquet('dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/*.parquet')
#df.printSchema()
display(df)
print(df.count())

# COMMAND ----------

df = spark.read.parquet('dbfs:/FileStore/paraquetdata')
display(df)
print('count of dataframe is ' +str(df.count()))

# COMMAND ----------

help(df.write)

# COMMAND ----------

df.write.parquet("/Filestore/paraquetoutput.parquet",mode='overwrite')

# COMMAND ----------

display(df)

# COMMAND ----------

