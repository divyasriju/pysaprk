# Databricks notebook source
from pyspark.sql.functions import *
df = spark.read.option("nullValue","null").csv("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/employee.csv",header=True)

df.createOrReplaceTempView("df")
display(df)

# COMMAND ----------

# Take null values count at each column
null_cols = df.select([count(when(col(c).isNull(), c)).alias(c) for c in df.columns])
null_cols.show()

# COMMAND ----------

# Filter only columns are having null record count..
df_out = null_cols.select([key for (key,value) in null_cols.collect()[0].asDict().items() if value> 0])
df_out.show()


# COMMAND ----------

from pyspark.sql.functions import spark_partition_id
df = spark.read.format("delta").load("/user/hive/warehouse/emp").repartition(4,"DEPTNO").withColumn("PARTITION_ID",spark_partition_id())
df.createOrReplaceTempView("df")
display(df)