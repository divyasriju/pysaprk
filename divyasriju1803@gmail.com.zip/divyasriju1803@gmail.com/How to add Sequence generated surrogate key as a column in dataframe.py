# Databricks notebook source
# MAGIC %md
# MAGIC ## How to add Sequence generated surrogate key as a column in dataframe.
# MAGIC * __`Answer`__ using `monotonically_increasing_id` or `hash` functions we can generate sequence or surrogate key

# COMMAND ----------

from pyspark.sql.functions import monotonically_increasing_id
df = spark.read.option("nullValue","null").csv("/FileStore/tables/emp.csv",header=True,inferSchema=True)
# Creating new column as partition_id using monotonically_increasing_id() function
df = df.withColumn("ID_KEY",monotonically_increasing_id())
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using `MD5`

# COMMAND ----------

from pyspark.sql.functions import md5,col

# Creating new column as partition_id using md5() function
df  = df.withColumn("MD5_KEY",md5(col("EMPNO").cast("string")))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using `CRC32`

# COMMAND ----------

from pyspark.sql.functions import crc32,col

# Creating new column as partition_id using md5() function
df = df.withColumn("CRC32_KEY",crc32(col("EMPNO").cast("string")))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using `sha2`

# COMMAND ----------

from pyspark.sql.functions import sha2

# Creating new column as partition_id using md5() function
df = df.withColumn("SHA2_KEY",sha2(col("EMPNO").cast("string"),256))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Using window function `row_number()`

# COMMAND ----------

from pyspark.sql.functions import sha2,row_number,lit
from pyspark.sql.window import Window

# Creating new column as partition_id using md5() function
df =df.withColumn("ROW_NUMBER",row_number().over(Window.partitionBy(lit('')).orderBy(lit(''))))
display(df)