# Databricks notebook source
from pyspark.sql import SparkSession



# Create Spark session
spark = SparkSession.builder.appName( "Python Example - PySpark Read XML").master("local").getOrCreate()


df = spark.read.format("xml").option("rootTag","root")\
    .option("rowTag","row").load("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/employee.xml")
df.printSchema()
df.show()

# COMMAND ----------

df.select("*").write.format("csv").option("rootTag", "root").option("rowTag", "row").mode(
    "overwrite").save("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/text2.xml")

# COMMAND ----------

display(df)

# COMMAND ----------

df.select("*").write.format("xml").option("rootTag", "root").option("rowTag", "row").save("dbfs:/FileStore/shared_uploads/divyasriju1803@gmail.com/text3.xml",mode="overwrite")

# COMMAND ----------

display(df)

# COMMAND ----------

