# Databricks notebook source
import pyspark
from pyspark.sql import SparkSession


spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()
data = [("111",50000),("222",60000),("333",40000)]
columns= ["EmpId","Salary"]
df = spark.createDataFrame(data =data,schema =columns)
df.printSchema()
df.show(truncate=False)

from pyspark.sql.functions import col,lit
df2 = df.select(col("EmpId"),col("Salary"),lit("1").alias("lit_value1"))
df2.show(truncate=False)




# COMMAND ----------

from pyspark.sql.functions import when, lit, col
df3 = df2.withColumn("lit_new",when(col("Salary") >=40000 & col("Salary") <= 50000,lit("100")).otherwise(lit("200")))
df3.show(truncate=False)

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.functions import when
pyspark_fun =SparkSession.builder.appName ('pyspark lit function').getOrCreate()
data_fun=[("11",110),("13",120),("15",130)]
data_col=["stud_id","stud_code"]
df =pyspark_fun.createDataFrame (data = data_fun, schema = data_col)
df2 =df.select(col("stud_id"), col("stud_code"), lit("9").alias("stud_age"))
df3 =df2.withColumn("140",when(col("stud_code")>= 120\
                                & col("stud_code")<= 100,lit("105"))\
                    .otherwise(lit("110")))
df3.show(truncate=False)

# COMMAND ----------

